# LunaRover AI 🛰️
### Autonomous Lunar Rover Navigation and Mission Planning

**Project Name:** LunaRover AI  
**Description:** An AI-driven system for autonomous navigation of a lunar rover, including terrain analysis, path planning (A*), obstacle avoidance, and mission dashboard for energy and task monitoring.

## Features
- 3D Terrain Mapping
- A* Path Planning for optimal navigation
- Obstacle Detection and Traversal Cost Analysis
- Mission Dashboard with battery, energy, and task metrics
- Autonomous mission execution with waypoints

## Installation
```bash
pip install -r requirements.txt
python main.py
```

## Usage
- Visualize 3D lunar terrain
- Execute autonomous path planning
- Monitor mission dashboard for rover metrics

## Technologies
- Python
- NumPy, Matplotlib
- Path Planning Algorithms (A*)
- AI/ML for terrain analysis and navigation

## License
MIT License
