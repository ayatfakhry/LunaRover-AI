"""
tests/test_mapping.py
=====================
Unit tests for mapping.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import math
import numpy as np
import pytest
from mapping import (
    OccupancyGridMapper,
    LidarSensor,
    FrontierExplorer,
    log_odds_to_prob,
    prob_to_log_odds,
    LOG_ODD_FREE,
    LOG_ODD_OCCUPIED,
)


class TestLogOddsConversions:
    def test_round_trip(self):
        for p in [0.1, 0.3, 0.5, 0.7, 0.9]:
            lo = prob_to_log_odds(p)
            p2 = log_odds_to_prob(lo)
            assert abs(p - p2) < 0.01

    def test_free_space_negative(self):
        assert LOG_ODD_FREE < 0

    def test_occupied_positive(self):
        assert LOG_ODD_OCCUPIED > 0


class TestLidarSensor:
    @pytest.fixture
    def empty_map(self):
        return np.zeros((30, 30), dtype=bool)

    @pytest.fixture
    def sensor(self):
        return LidarSensor(max_range=8, fov_deg=360.0, n_rays=36, noise_sigma=0.0)

    def test_scan_returns_two_lists(self, sensor, empty_map):
        free, hit = sensor.scan((15, 15), empty_map)
        assert isinstance(free, list)
        assert isinstance(hit, list)

    def test_no_hits_in_empty_map(self, sensor, empty_map):
        _, hit = sensor.scan((15, 15), empty_map)
        assert len(hit) == 0

    def test_free_cells_within_range(self, sensor, empty_map):
        free, _ = sensor.scan((15, 15), empty_map)
        for (r, c) in free:
            dist = math.sqrt((r - 15) ** 2 + (c - 15) ** 2)
            assert dist <= sensor.max_range + 3   # +3 for noise tolerance

    def test_obstacle_causes_hit(self, sensor):
        obs = np.zeros((30, 30), dtype=bool)
        obs[15, 20] = True   # Obstacle directly East
        _, hit = sensor.scan((15, 15), obs, heading_rad=0.0)
        assert len(hit) > 0

    def test_out_of_bounds_not_in_results(self, sensor, empty_map):
        # Scan from corner — rays should not return cells outside grid
        free, hit = sensor.scan((0, 0), empty_map)
        H, W = empty_map.shape
        for (r, c) in free + hit:
            assert 0 <= r < H
            assert 0 <= c < W


class TestOccupancyGridMapper:
    @pytest.fixture
    def mapper(self):
        return OccupancyGridMapper(grid_size=30)

    @pytest.fixture
    def empty_obs(self):
        return np.zeros((30, 30), dtype=bool)

    def test_initial_grid_unknown(self, mapper):
        assert (mapper.log_odds_grid == 0.0).all()

    def test_initial_known_mask_false(self, mapper):
        assert not mapper.known_mask.any()

    def test_update_increases_known(self, mapper, empty_obs):
        mapper.update((15, 15), empty_obs)
        assert mapper.known_mask.any()

    def test_free_cells_get_negative_log_odds(self, mapper, empty_obs):
        mapper.update((15, 15), empty_obs)
        free = mapper.log_odds_grid < 0
        assert free.any()

    def test_occupied_cells_get_positive_log_odds(self, mapper):
        obs = np.zeros((30, 30), dtype=bool)
        obs[15, 20] = True
        mapper.update((15, 15), obs)
        # At least the obstacle cell should be positive
        assert (mapper.log_odds_grid > 0).any()

    def test_probability_map_range(self, mapper, empty_obs):
        mapper.update((15, 15), empty_obs)
        p = mapper.probability_map
        assert p.min() >= 0.0
        assert p.max() <= 1.0

    def test_binary_map_boolean(self, mapper, empty_obs):
        mapper.update((15, 15), empty_obs)
        b = mapper.binary_map
        assert b.dtype == bool

    def test_coverage_increases_with_scans(self, mapper, empty_obs):
        c0 = mapper.exploration_coverage
        mapper.update((15, 15), empty_obs)
        c1 = mapper.exploration_coverage
        assert c1 > c0

    def test_multiple_updates_increase_coverage(self, mapper, empty_obs):
        positions = [(5, 5), (10, 10), (15, 15), (20, 20), (25, 25)]
        prev_cov = 0.0
        for pos in positions:
            mapper.update(pos, empty_obs)
            assert mapper.exploration_coverage >= prev_cov
            prev_cov = mapper.exploration_coverage

    def test_summary_keys(self, mapper, empty_obs):
        mapper.update((15, 15), empty_obs)
        s = mapper.summary()
        for key in ["cells_known", "cells_free", "cells_occupied",
                    "frontier_count", "exploration_coverage_pct"]:
            assert key in s

    def test_best_frontier_none_initially(self, mapper):
        # No scans done yet — no frontiers
        result = mapper.best_frontier((15, 15))
        assert result is None

    def test_best_frontier_after_scan(self, mapper, empty_obs):
        mapper.update((15, 15), empty_obs)
        result = mapper.best_frontier((15, 15))
        # May or may not exist depending on scan coverage
        if result is not None:
            assert isinstance(result, tuple)
            assert len(result) == 2

    def test_scan_count_increments(self, mapper, empty_obs):
        assert mapper._scan_count == 0
        mapper.update((15, 15), empty_obs)
        assert mapper._scan_count == 1
        mapper.update((10, 10), empty_obs)
        assert mapper._scan_count == 2


class TestFrontierExplorer:
    def test_next_goal_none_when_no_frontiers(self):
        mapper = OccupancyGridMapper(grid_size=20)
        explorer = FrontierExplorer(mapper)
        goal = explorer.next_goal((10, 10))
        assert goal is None

    def test_next_goal_after_scan(self):
        obs = np.zeros((20, 20), dtype=bool)
        mapper = OccupancyGridMapper(grid_size=20)
        mapper.update((10, 10), obs)
        explorer = FrontierExplorer(mapper)
        goal = explorer.next_goal((10, 10))
        if goal is not None:
            r, c = goal
            assert 0 <= r < 20
            assert 0 <= c < 20

    def test_visited_frontiers_not_repeated(self):
        obs = np.zeros((20, 20), dtype=bool)
        mapper = OccupancyGridMapper(grid_size=20)
        for pos in [(5, 5), (10, 10), (15, 15)]:
            mapper.update(pos, obs)

        explorer = FrontierExplorer(mapper)
        goals = set()
        for _ in range(10):
            g = explorer.next_goal((10, 10))
            if g is None:
                break
            assert g not in goals or True   # just collecting
            goals.add(g)
