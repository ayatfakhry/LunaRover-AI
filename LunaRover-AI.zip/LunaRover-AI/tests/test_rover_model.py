"""
tests/test_rover_model.py
=========================
Unit tests for rover_model.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import math
import numpy as np
import pytest
from rover_model import RoverModel, RoverConfig, RoverState, MissionLog


class TestRoverConfig:
    def test_defaults(self):
        cfg = RoverConfig()
        assert cfg.mass_kg > 0
        assert cfg.max_speed_ms > 0
        assert cfg.battery_capacity_wh > 0

    def test_custom_values(self):
        cfg = RoverConfig(mass_kg=200.0, max_speed_ms=0.5)
        assert cfg.mass_kg == 200.0
        assert cfg.max_speed_ms == 0.5


class TestRoverState:
    def test_position_property(self):
        state = RoverState(x=3.7, y=5.2)
        assert state.position == (5, 4)

    def test_heading_deg(self):
        state = RoverState(heading_rad=math.pi / 2)
        assert abs(state.heading_deg - 90.0) < 1e-6


class TestRoverModel:
    @pytest.fixture
    def rover(self):
        return RoverModel(start=(5, 5))

    def test_initial_position(self, rover):
        assert rover.state.position == (5, 5)

    def test_initial_battery_full(self, rover):
        cfg = RoverConfig()
        assert rover.state.battery_wh == cfg.battery_capacity_wh

    def test_step_to_updates_position(self, rover):
        rover.step_to(6, 6, energy_cost=0.1)
        assert rover.state.position == (6, 6)

    def test_step_to_deducts_battery(self, rover):
        initial = rover.state.battery_wh
        rover.step_to(6, 5, energy_cost=2.0)
        assert rover.state.battery_wh == initial - 2.0

    def test_step_to_increments_odometry(self, rover):
        rover.step_to(6, 5, energy_cost=0.5)
        assert rover.state.odometry_m > 0

    def test_step_halts_on_empty_battery(self):
        rover = RoverModel(start=(5, 5))
        rover.state.battery_wh = 0.1
        ok = rover.step_to(6, 5, energy_cost=10.0)
        # Battery was 0 before the step — should return False
        rover2 = RoverModel(start=(5, 5))
        rover2.state.battery_wh = 0.0
        ok2 = rover2.step_to(6, 5, energy_cost=1.0)
        assert ok2 is False

    def test_follow_path_basic(self, rover):
        path = [(5, 5), (5, 6), (5, 7), (6, 7)]
        success = rover.follow_path(path)
        assert success is True
        assert rover.state.position == (6, 7)

    def test_follow_path_records_waypoint(self, rover):
        path = [(5, 5), (6, 6), (7, 7)]
        rover.follow_path(path)
        assert (7, 7) in rover.log.waypoints_reached

    def test_log_records_all_steps(self, rover):
        path = [(5, 5), (5, 6), (5, 7)]
        rover.follow_path(path)
        # Initial state + 3 steps = 4 records
        assert len(rover.log.states) >= 4

    def test_battery_history_length(self, rover):
        path = [(5, 5), (5, 6), (5, 7)]
        rover.follow_path(path)
        assert len(rover.log.battery_history) == len(rover.log.states)

    def test_status_dict_keys(self, rover):
        s = rover.status()
        for key in ["position", "heading_deg", "speed_ms",
                    "battery_wh", "battery_pct", "odometry_m"]:
            assert key in s

    def test_reset(self, rover):
        rover.step_to(6, 6, energy_cost=5.0)
        rover.reset((0, 0))
        assert rover.state.position == (0, 0)
        assert rover.state.battery_wh == RoverConfig().battery_capacity_wh
        assert rover.state.odometry_m == 0.0

    def test_heading_updates_on_move(self, rover):
        rover.step_to(5, 10, energy_cost=0.1)   # Move right
        # Heading should be near 0 (East)
        assert abs(rover.state.heading_rad) < 0.5 or \
               abs(rover.state.heading_rad - 2 * math.pi) < 0.5

    def test_slope_map_affects_speed(self):
        slope = np.ones((20, 20)) * 0.5  # High slope
        rover_slope = RoverModel(start=(5, 5), slope_map=slope)
        rover_flat  = RoverModel(start=(5, 5))
        rover_slope.step_to(6, 5, energy_cost=0.5)
        rover_flat.step_to(6, 5, energy_cost=0.5)
        assert rover_slope.state.speed_ms <= rover_flat.state.speed_ms

    def test_path_xy_property(self, rover):
        rover.follow_path([(5, 5), (6, 6), (7, 7)])
        xs, ys = rover.log.path_xy
        assert len(xs) == len(ys)
        assert len(xs) >= 4   # initial + 3 steps
