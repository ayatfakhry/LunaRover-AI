"""
tests/test_terrain.py
=====================
Unit tests for terrain_generator.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import numpy as np
import pytest
from terrain_generator import (
    LunarTerrainGenerator,
    diamond_square,
    add_craters,
    add_rocks,
)


class TestDiamondSquare:
    def test_output_shape(self):
        h = diamond_square(64, seed=0)
        assert h.shape == (64, 64)

    def test_values_in_range(self):
        h = diamond_square(64, seed=1)
        assert h.min() >= 0.0
        assert h.max() <= 1.0

    def test_reproducibility(self):
        h1 = diamond_square(32, seed=99)
        h2 = diamond_square(32, seed=99)
        np.testing.assert_array_equal(h1, h2)

    def test_different_seeds(self):
        h1 = diamond_square(32, seed=1)
        h2 = diamond_square(32, seed=2)
        assert not np.allclose(h1, h2)

    def test_roughness_effect(self):
        smooth = diamond_square(64, roughness=0.1, seed=5)
        rough  = diamond_square(64, roughness=0.9, seed=5)
        # Rougher terrain has higher std
        assert rough.std() >= smooth.std() * 0.8


class TestCraters:
    def test_craters_lower_mean(self):
        h = diamond_square(64, seed=42)
        hc = add_craters(h, n_craters=10, seed=42)
        # After craters, normalised map still valid
        assert hc.min() >= 0.0
        assert hc.max() <= 1.0

    def test_output_shape_preserved(self):
        h = diamond_square(64, seed=0)
        hc = add_craters(h, n_craters=5, seed=0)
        assert hc.shape == h.shape


class TestRockOverlay:
    def test_rocks_increase_max(self):
        h = diamond_square(64, seed=0)
        hr = add_rocks(h, density=0.02, seed=0)
        assert hr.shape == h.shape
        assert hr.min() >= 0.0
        assert hr.max() <= 1.0


class TestLunarTerrainGenerator:
    @pytest.fixture
    def terrain(self):
        return LunarTerrainGenerator(grid_size=64, seed=42).generate()

    def test_heightmap_shape(self, terrain):
        assert terrain.heightmap.shape == (64, 64)

    def test_heightmap_range(self, terrain):
        assert terrain.heightmap.min() >= 0.0
        assert terrain.heightmap.max() <= 1.0

    def test_slope_map_shape(self, terrain):
        assert terrain.slope_map.shape == (64, 64)

    def test_slope_map_non_negative(self, terrain):
        assert (terrain.slope_map >= 0).all()

    def test_hazard_map_boolean(self, terrain):
        assert terrain.hazard_map.dtype == bool

    def test_terrain_labels_range(self, terrain):
        assert terrain.terrain_labels.min() >= 0
        assert terrain.terrain_labels.max() <= 4

    def test_traversal_cost_positive(self, terrain):
        cost = terrain.get_traversal_cost()
        assert (cost > 0).all()

    def test_hazard_cells_have_high_cost(self, terrain):
        cost = terrain.get_traversal_cost(hazard_penalty=1e6)
        assert cost[terrain.hazard_map].min() > 1e5

    def test_summary_keys(self, terrain):
        s = terrain.summary()
        for key in ["grid_size", "elevation_min", "elevation_max",
                    "slope_mean", "hazard_fraction", "class_counts"]:
            assert key in s

    def test_reproducibility(self):
        t1 = LunarTerrainGenerator(grid_size=32, seed=7).generate()
        t2 = LunarTerrainGenerator(grid_size=32, seed=7).generate()
        np.testing.assert_array_equal(t1.heightmap, t2.heightmap)
