"""
tests/test_path_planner.py
==========================
Unit tests for path_planner.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import math
import numpy as np
import pytest
from path_planner import (
    astar, dijkstra, smooth_path, PathPlanner,
    _heuristic_euclidean, _heuristic_manhattan, _heuristic_octile,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def flat_map():
    """10x10 uniform cost map — all cells traversable."""
    return np.ones((10, 10), dtype=float)


@pytest.fixture
def wall_map():
    """10x10 map with a vertical wall blocking naive paths."""
    m = np.ones((10, 10), dtype=float)
    m[:8, 5] = 1e7       # Wall from row 0..7 at col 5
    return m


@pytest.fixture
def island_map():
    """8x8 map where goal is completely surrounded by obstacles."""
    m = np.ones((8, 8), dtype=float)
    for r in range(2, 6):
        for c in range(2, 6):
            m[r, c] = 1e7
    return m


# ---------------------------------------------------------------------------
# Heuristics
# ---------------------------------------------------------------------------

class TestHeuristics:
    def test_euclidean_same_cell(self):
        assert _heuristic_euclidean((3, 3), (3, 3)) == 0.0

    def test_euclidean_diagonal(self):
        assert abs(_heuristic_euclidean((0, 0), (3, 4)) - 5.0) < 1e-9

    def test_manhattan(self):
        assert _heuristic_manhattan((0, 0), (3, 4)) == 7

    def test_octile_cardinal(self):
        # Moving 4 steps along a row
        assert abs(_heuristic_octile((0, 0), (0, 4)) - 4.0) < 1e-9

    def test_octile_diagonal_pure(self):
        val = _heuristic_octile((0, 0), (3, 3))
        expected = 3 * math.sqrt(2)
        assert abs(val - expected) < 1e-9


# ---------------------------------------------------------------------------
# A*
# ---------------------------------------------------------------------------

class TestAstar:
    def test_finds_path_flat(self, flat_map):
        path, cost = astar(flat_map, (0, 0), (9, 9))
        assert path is not None
        assert len(path) >= 2
        assert path[0] == (0, 0)
        assert path[-1] == (9, 9)

    def test_path_cost_positive(self, flat_map):
        _, cost = astar(flat_map, (0, 0), (9, 9))
        assert cost > 0

    def test_navigates_wall(self, wall_map):
        path, cost = astar(wall_map, (0, 0), (0, 9))
        assert path is not None
        # Must go around the wall (row >= 8)
        cols_at_wall = [c for r, c in path if c == 5]
        rows_at_wall = [r for r, c in path if c == 5]
        if rows_at_wall:
            assert max(rows_at_wall) >= 8

    def test_no_path_when_blocked(self, island_map):
        # Goal at (3, 3) is inside the obstacle island
        path, cost = astar(island_map, (0, 0), (3, 3))
        assert path is None
        assert cost == math.inf

    def test_start_equals_goal(self, flat_map):
        path, cost = astar(flat_map, (5, 5), (5, 5))
        assert path is not None
        assert path[0] == (5, 5)

    def test_out_of_bounds_start(self, flat_map):
        path, cost = astar(flat_map, (-1, 0), (9, 9))
        assert path is None

    def test_different_heuristics_same_goal(self, flat_map):
        p_e, _ = astar(flat_map, (0, 0), (9, 9), heuristic="euclidean")
        p_m, _ = astar(flat_map, (0, 0), (9, 9), heuristic="manhattan")
        p_o, _ = astar(flat_map, (0, 0), (9, 9), heuristic="octile")
        for p in [p_e, p_m, p_o]:
            assert p is not None
            assert p[-1] == (9, 9)


# ---------------------------------------------------------------------------
# Dijkstra
# ---------------------------------------------------------------------------

class TestDijkstra:
    def test_finds_path_flat(self, flat_map):
        path, cost = dijkstra(flat_map, (0, 0), (9, 9))
        assert path is not None
        assert path[-1] == (9, 9)

    def test_navigates_wall(self, wall_map):
        path, cost = dijkstra(wall_map, (0, 0), (0, 9))
        assert path is not None

    def test_no_path_when_blocked(self, island_map):
        path, cost = dijkstra(island_map, (0, 0), (3, 3))
        assert path is None

    def test_astar_vs_dijkstra_cost(self, wall_map):
        """A* and Dijkstra should find paths of similar cost."""
        _, c_astar = astar(wall_map, (0, 0), (9, 9))
        _, c_dijk  = dijkstra(wall_map, (0, 0), (9, 9))
        assert abs(c_astar - c_dijk) / (c_dijk + 1e-9) < 0.05


# ---------------------------------------------------------------------------
# Path utilities
# ---------------------------------------------------------------------------

class TestSmoothPath:
    def test_endpoints_preserved(self):
        path = [(0, 0), (1, 1), (2, 3), (4, 5), (6, 6)]
        smoothed = smooth_path(path, iterations=3)
        assert smoothed[0] == path[0]
        assert smoothed[-1] == path[-1]

    def test_trivial_path(self):
        path = [(0, 0), (1, 1)]
        smoothed = smooth_path(path)
        assert len(smoothed) == 2


# ---------------------------------------------------------------------------
# PathPlanner facade
# ---------------------------------------------------------------------------

class TestPathPlanner:
    def test_plan_astar(self, flat_map):
        planner = PathPlanner(flat_map, algorithm="astar")
        path, cost = planner.plan((0, 0), (9, 9))
        assert path is not None

    def test_plan_dijkstra(self, flat_map):
        planner = PathPlanner(flat_map, algorithm="dijkstra")
        path, cost = planner.plan((0, 0), (9, 9))
        assert path is not None

    def test_multi_waypoint(self, flat_map):
        planner = PathPlanner(flat_map, algorithm="astar")
        waypoints = [(0, 0), (0, 9), (9, 9)]
        path, cost = planner.plan_multi_waypoint(waypoints)
        assert path is not None
        assert len(path) > 2

    def test_statistics(self, flat_map):
        planner = PathPlanner(flat_map, algorithm="astar")
        path, _ = planner.plan((0, 0), (9, 9))
        stats = planner.path_statistics(path)
        assert "num_cells" in stats
        assert "tortuosity" in stats
        assert stats["tortuosity"] >= 1.0

    def test_invalid_algorithm(self, flat_map):
        planner = PathPlanner(flat_map, algorithm="astar")
        planner.algorithm = "invalid"
        with pytest.raises(ValueError):
            planner.plan((0, 0), (5, 5))
