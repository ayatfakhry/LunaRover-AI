"""
tests/test_energy_model.py
==========================
Unit tests for energy_model.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import numpy as np
import pytest
from energy_model import EnergyModel, PowerBudget, LUNAR_GRAVITY


class TestPowerBudget:
    def test_net_power(self):
        b = PowerBudget(propulsion_w=50.0, climbing_w=20.0,
                        slip_loss_w=5.0, base_draw_w=45.0,
                        solar_gain_w=100.0)
        assert b.net_power_w == pytest.approx(20.0, abs=1e-6)

    def test_total_draw(self):
        b = PowerBudget(propulsion_w=50.0, climbing_w=20.0,
                        slip_loss_w=5.0, base_draw_w=45.0)
        assert b.total_draw_w == pytest.approx(120.0, abs=1e-6)

    def test_net_power_no_solar(self):
        b = PowerBudget(propulsion_w=30.0, base_draw_w=45.0)
        assert b.net_power_w == pytest.approx(75.0, abs=1e-6)


class TestEnergyModel:
    @pytest.fixture
    def model(self):
        return EnergyModel(mass_kg=180.0, base_power_w=45.0,
                           solar_power_w=120.0, cell_size_m=1.0)

    def test_step_energy_positive(self, model):
        e, budget = model.compute_step_energy(
            (0, 0), (1, 0),
            slope_magnitude=0.1,
            speed_ms=0.2,
        )
        assert e >= 0.0

    def test_step_energy_zero_distance(self, model):
        e, budget = model.compute_step_energy(
            (0, 0), (0, 0),
            slope_magnitude=0.0,
            speed_ms=0.2,
        )
        assert e == 0.0

    def test_step_energy_zero_speed(self, model):
        e, budget = model.compute_step_energy(
            (0, 0), (1, 0),
            slope_magnitude=0.0,
            speed_ms=0.0,
        )
        assert e == 0.0

    def test_steep_slope_costs_more(self, model):
        e_flat, _ = model.compute_step_energy(
            (0, 0), (1, 0), slope_magnitude=0.0, speed_ms=0.2
        )
        e_steep, _ = model.compute_step_energy(
            (0, 0), (1, 0), slope_magnitude=0.6, speed_ms=0.2
        )
        assert e_steep >= e_flat

    def test_solar_reduces_energy(self, model):
        e_sun,  _ = model.compute_step_energy(
            (0, 0), (1, 0), slope_magnitude=0.1,
            speed_ms=0.2, illuminated=True
        )
        e_dark, _ = model.compute_step_energy(
            (0, 0), (1, 0), slope_magnitude=0.1,
            speed_ms=0.2, illuminated=False
        )
        assert e_dark >= e_sun

    def test_history_grows(self, model):
        for i in range(5):
            model.compute_step_energy(
                (0, 0), (1, 0), slope_magnitude=0.1, speed_ms=0.2
            )
        assert len(model._history) == 5

    def test_total_energy_accumulates(self, model):
        """Total gross energy drawn (before solar offset) must be positive."""
        n = 3
        for _ in range(n):
            model.compute_step_energy(
                (0, 0), (1, 0), slope_magnitude=0.1, speed_ms=0.2
            )
        # _total_energy_j stores max(0, net); gross draw is always positive
        assert model._total_energy_j >= 0.0
        # The history list grows — energy was computed
        assert len(model._history) == n

    def test_path_energy_length(self, model):
        slope_map = np.zeros((10, 10))
        heightmap = np.zeros((10, 10))
        path = [(0, i) for i in range(5)]
        total, per_step = model.estimate_path_energy(
            path, slope_map, heightmap, speed_ms=0.2
        )
        assert len(per_step) == len(path) - 1
        assert total == pytest.approx(sum(per_step), rel=1e-6)

    def test_path_energy_empty_path(self, model):
        slope_map = np.zeros((10, 10))
        heightmap = np.zeros((10, 10))
        total, per_step = model.estimate_path_energy(
            [], slope_map, heightmap
        )
        assert total == 0.0
        assert per_step == []

    def test_max_range_positive(self, model):
        r = model.max_range_cells(battery_wh=500.0)
        assert r > 0

    def test_energy_breakdown_keys(self, model):
        model.compute_step_energy(
            (0, 0), (1, 0), slope_magnitude=0.1, speed_ms=0.2
        )
        bd = model.energy_breakdown()
        for key in ["propulsion_pct", "climbing_pct", "slip_loss_pct",
                    "base_draw_pct", "net_energy_wh"]:
            assert key in bd

    def test_reset_clears_history(self, model):
        model.compute_step_energy(
            (0, 0), (1, 0), slope_magnitude=0.1, speed_ms=0.2
        )
        model.reset()
        assert len(model._history) == 0
        assert model.total_energy_wh == 0.0
