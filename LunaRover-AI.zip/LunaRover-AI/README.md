# 🌕 LunaRover AI: Autonomous Lunar Rover Navigation and Exploration System

> A research-grade simulation framework for autonomous lunar rover navigation, terrain analysis, obstacle avoidance, and AI-driven exploration planning.

---

## Overview

**LunaRover AI** is a modular, simulation-based system designed for aerospace robotics research. It replicates the challenges of navigating a rover across procedurally generated lunar terrain — complete with craters, rocks, slopes, and shadowed regions — while employing AI-driven decision-making for safe and efficient exploration.

This project demonstrates:
- Synthetic lunar terrain generation using fractal noise and physical constraints
- A* and Dijkstra pathfinding with terrain-aware cost functions
- AI terrain classification using scikit-learn (Random Forest, SVM)
- SLAM-inspired occupancy grid mapping with ray-casting
- Realistic energy consumption modeling per traversal step
- Comprehensive mission planning with priority-based waypoint scheduling
- Full visualization suite: terrain maps, path overlays, SLAM maps, energy plots
- Unit-tested modules with coverage reporting

---

## Project Structure

```
LunaRover-AI/
├── README.md                        # This file
├── requirements.txt                 # Python dependencies
├── main.py                          # Primary entry point
├── data/                            # Auto-populated terrain and config data
├── src/
│   ├── terrain_generator.py         # Procedural lunar terrain synthesis
│   ├── rover_model.py               # Rover kinematics and state model
│   ├── obstacle_detection.py        # CV-based + gradient obstacle detection
│   ├── path_planner.py              # A* / Dijkstra path planning
│   ├── mapping.py                   # SLAM-inspired occupancy grid mapping
│   ├── mission_planner.py           # Waypoint scheduling and mission control
│   ├── energy_model.py              # Energy consumption estimation
│   └── visualization.py            # Plotting and animation tools
├── scripts/
│   └── run_rover_simulation.py      # Full end-to-end simulation runner
├── results/                         # Auto-saved outputs (maps, plots, reports)
└── tests/
    ├── test_terrain.py
    ├── test_path_planner.py
    ├── test_rover_model.py
    ├── test_energy_model.py
    └── test_mapping.py
```

---

## Installation

### Requirements
- Python 3.9+
- pip

### Setup

```bash
# Clone the repository
git clone https://github.com/your-org/LunaRover-AI.git
cd LunaRover-AI

# Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

---

## Quick Start

### Run Full Simulation
```bash
python main.py
```

### Run Detailed Simulation Script
```bash
python scripts/run_rover_simulation.py --grid_size 128 --seed 42 --algorithm astar
```

### Run Unit Tests
```bash
python -m pytest tests/ -v --tb=short
```

---

## Modules

### `terrain_generator.py`
Generates a synthetic lunar heightmap using Diamond-Square fractal noise combined with Gaussian crater placement. Outputs a normalized elevation grid with annotated hazard zones.

### `rover_model.py`
Implements a differential-drive rover kinematic model. Tracks position, heading, velocity, and cumulative odometry. Supports step-by-step state updates.

### `obstacle_detection.py`
Detects traversal hazards using:
- **Slope analysis**: Gradient magnitude thresholding on the heightmap
- **OpenCV morphology**: Erosion/dilation for rock cluster detection
- **Shadow masking**: Simulated low-angle illumination for shadow regions

### `path_planner.py`
Provides two planning algorithms:
- **A\***: Heuristic-driven optimal path search (Manhattan + Euclidean heuristics)
- **Dijkstra**: Exhaustive cost-minimizing search
Both use terrain-aware cost functions weighting slope penalty and energy expenditure.

### `mapping.py`
A SLAM-inspired occupancy grid mapper that:
- Updates probabilistic cell occupancy via log-odds updates
- Simulates a virtual LiDAR sensor with configurable range/FOV
- Tracks explored vs. unexplored frontiers

### `mission_planner.py`
Schedules multi-waypoint missions with:
- Priority-based goal ordering (science targets, checkpoints, return-to-base)
- Dynamic re-routing on obstacle discovery
- Mission status tracking and reporting

### `energy_model.py`
Estimates energy consumption per step as a function of:
- Terrain slope (climbing penalty)
- Rover velocity
- Wheel slip factor (slope-dependent)
- Base electrical draw

### `visualization.py`
Renders publication-quality plots:
- 3D terrain surface with rover path overlay
- 2D occupancy map with frontier visualization
- Energy consumption timeline
- Side-by-side mission summary panels

---

## Algorithm Details

### A* Path Planning
The cost function combines:
```
f(n) = g(n) + h(n)
g(n) = cumulative_terrain_cost (slope + energy penalty)
h(n) = euclidean_distance_to_goal * base_cost
```

### Terrain Classification
A Random Forest classifier categorizes cells into:
- `FLAT` — safe traversal
- `ROCKY` — reduced speed
- `CRATER_RIM` — high risk
- `CRATER_FLOOR` — avoid
- `SLOPE` — energy-intensive

Features: local elevation mean, std, gradient magnitude, curvature, aspect ratio.

---

## Example Results

After running the full simulation, results are saved to `results/`:
- `terrain_heightmap.png` — Raw lunar surface
- `obstacle_map.png` — Detected hazards overlaid
- `planned_path.png` — A* path on cost map
- `slam_map.png` — Occupancy grid after traversal
- `energy_profile.png` — Energy usage over mission
- `mission_report.txt` — Full mission summary

---

## Research Applications

- Autonomous planetary rover path planning benchmarking
- SLAM algorithm validation on synthetic extraterrestrial terrain
- Energy-optimal trajectory planning for solar-powered rovers
- AI terrain classification for NASA/ESA mission simulation
- Reinforcement learning environment scaffold (extend `rover_model.py`)

---

## License

MIT License — Free to use for academic and research purposes.

---

## Citation

If you use LunaRover AI in your research, please cite:
```
@software{lunarover_ai,
  title  = {LunaRover AI: Autonomous Lunar Rover Navigation and Exploration System},
  year   = {2025},
  note   = {Simulation framework for aerospace robotics research}
}
```
