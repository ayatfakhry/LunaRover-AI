"""
main.py
=======
LunaRover AI — Primary entry point.

Orchestrates the full simulation pipeline:
  1. Generate synthetic lunar terrain
  2. Detect obstacles (multi-modal)
  3. Plan mission waypoints
  4. Execute A* path planning
  5. Simulate rover traversal
  6. Update SLAM occupancy map
  7. Estimate energy consumption
  8. Evaluate performance metrics
  9. Render and save all visualizations
  10. Print mission report
"""

import os
import sys
import time
import argparse
import numpy as np

# Ensure src/ is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from terrain_generator  import LunarTerrainGenerator
from rover_model        import RoverModel, RoverConfig
from obstacle_detection import ObstacleDetector
from path_planner       import PathPlanner
from mapping            import OccupancyGridMapper, LidarSensor
from mission_planner    import MissionPlanner
from energy_model       import EnergyModel
from visualization      import (
    plot_terrain,
    plot_obstacle_map,
    plot_path,
    plot_slam_map,
    plot_energy_profile,
    plot_terrain_classification,
    plot_3d_terrain,
    plot_mission_dashboard,
    plot_performance_metrics,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_start_goal(terrain, margin: int = 10):
    """Pick a safe start and goal that avoids hazard zones."""
    H, W = terrain.heightmap.shape
    hazard = terrain.hazard_map

    def _find_safe(r0, c0, search_r, search_c):
        for dr in range(-5, 6):
            for dc in range(-5, 6):
                r, c = r0 + dr * search_r, c0 + dc * search_c
                r, c = np.clip(r, 0, H - 1), np.clip(c, 0, W - 1)
                if not hazard[r, c]:
                    return (int(r), int(c))
        return (r0, c0)

    start = _find_safe(margin, margin, 1, 1)
    goal  = _find_safe(H - margin, W - margin, -1, -1)
    return start, goal


def _ensure_dirs(*dirs):
    for d in dirs:
        os.makedirs(d, exist_ok=True)


# ---------------------------------------------------------------------------
# Main simulation
# ---------------------------------------------------------------------------

def run_simulation(grid_size: int = 96,
                   seed: int = 42,
                   algorithm: str = "astar",
                   n_craters: int = 20,
                   n_waypoints: int = 5,
                   results_dir: str = "results",
                   verbose: bool = True) -> dict:

    _ensure_dirs(results_dir, "data")
    t0 = time.time()

    # ------------------------------------------------------------------ #
    # 1. Terrain generation
    # ------------------------------------------------------------------ #
    print("\n[1/9] Generating lunar terrain …")
    terrain = LunarTerrainGenerator(
        grid_size=grid_size,
        roughness=0.55,
        n_craters=n_craters,
        rock_density=0.012,
        seed=seed,
    ).generate()

    if verbose:
        summary = terrain.summary()
        print(f"      Grid: {grid_size}×{grid_size}  |  "
              f"Hazard fraction: {summary['hazard_fraction']:.2%}  |  "
              f"Mean slope: {summary['slope_mean']:.3f}")

    plot_terrain(terrain.heightmap,
                 save_path=os.path.join(results_dir, "terrain_heightmap.png"))
    plot_3d_terrain(terrain.heightmap,
                    save_path=os.path.join(results_dir, "terrain_3d.png"))

    # ------------------------------------------------------------------ #
    # 2. Obstacle detection
    # ------------------------------------------------------------------ #
    print("[2/9] Detecting obstacles …")
    detector = ObstacleDetector(slope_threshold=0.28,
                                 sun_azimuth_deg=40.0,
                                 sun_elevation_deg=12.0)
    obstacle_map = detector.detect(terrain.heightmap, terrain.slope_map)
    plot_obstacle_map(terrain.heightmap, obstacle_map,
                      save_path=os.path.join(results_dir, "obstacle_map.png"))
    plot_terrain_classification(
        detector.ai_labels if detector.ai_labels is not None else terrain.terrain_labels,
        save_path=os.path.join(results_dir, "terrain_classification.png"),
    )

    # ------------------------------------------------------------------ #
    # 3. Safe start / goal
    # ------------------------------------------------------------------ #
    start, goal = _safe_start_goal(terrain, margin=8)
    print(f"[3/9] Start={start}  Goal={goal}")

    # ------------------------------------------------------------------ #
    # 4. Mission planning
    # ------------------------------------------------------------------ #
    print("[4/9] Planning mission waypoints …")
    mission = MissionPlanner(
        rover_start=start,
        battery_capacity_wh=1500.0,
        energy_per_cell=0.45,
        grid_size=grid_size,
    )
    science_targets = MissionPlanner.generate_science_targets(
        terrain.heightmap, terrain.slope_map,
        n_targets=n_waypoints, seed=seed,
    )
    for wp in science_targets:
        mission.add_waypoint(wp)
    mission.add_checkpoint(goal[0], goal[1], "GOAL", priority=1)
    mission.set_return_base()
    mission.build_queue(strategy="priority")
    mission.start_mission()

    all_waypoints = list(mission.queue)
    waypoint_cells = [start] + [wp.position for wp in all_waypoints]

    # ------------------------------------------------------------------ #
    # 5. Path planning
    # ------------------------------------------------------------------ #
    print(f"[5/9] Planning path ({algorithm.upper()}) through "
          f"{len(waypoint_cells)} waypoints …")
    cost_map = terrain.get_traversal_cost(slope_weight=2.5, hazard_penalty=1e7)
    planner  = PathPlanner(cost_map, algorithm=algorithm,
                            obstacle_inflation=2)
    full_path, plan_cost = planner.plan_multi_waypoint(waypoint_cells)

    stats = planner.path_statistics(full_path)
    if verbose:
        print(f"      Path cells: {stats.get('num_cells', 0)}  |  "
              f"Length: {stats.get('geometric_length', 0):.1f} cells  |  "
              f"Tortuosity: {stats.get('tortuosity', 0):.3f}")

    plot_path(terrain.heightmap, cost_map, full_path,
              waypoints=all_waypoints,
              title=f"{algorithm.upper()} Planned Path",
              save_path=os.path.join(results_dir, "planned_path.png"))

    # ------------------------------------------------------------------ #
    # 6. Energy estimation
    # ------------------------------------------------------------------ #
    print("[6/9] Estimating energy consumption …")
    energy_model = EnergyModel(
        mass_kg=180.0,
        base_power_w=45.0,
        solar_power_w=120.0,
        cell_size_m=1.0,
    )
    total_energy_wh, per_step_energy = energy_model.estimate_path_energy(
        full_path,
        terrain.slope_map,
        terrain.heightmap,
        speed_ms=0.22,
        illumination_map=detector.shadow_mask,
    )
    if verbose:
        print(f"      Total energy: {total_energy_wh:.2f} Wh  |  "
              f"Steps: {len(per_step_energy)}  |  "
              f"Solar offset: {energy_model.total_solar_wh:.2f} Wh")

    # ------------------------------------------------------------------ #
    # 7. Rover simulation + SLAM mapping
    # ------------------------------------------------------------------ #
    print("[7/9] Simulating rover traversal + SLAM mapping …")
    rover_cfg = RoverConfig(
        max_speed_ms=0.28,
        battery_capacity_wh=1500.0,
        sensor_range_cells=14,
    )
    rover = RoverModel(
        config=rover_cfg,
        start=start,
        heightmap=terrain.heightmap,
        slope_map=terrain.slope_map,
        noise_sigma=0.0,
    )

    lidar  = LidarSensor(max_range=14, fov_deg=360.0, n_rays=72)
    mapper = OccupancyGridMapper(grid_size=grid_size, sensor=lidar)

    # Initial scan at start
    mapper.update(start, obstacle_map, heading_rad=rover.state.heading_rad)

    # Follow path in chunks, updating SLAM at each step
    for i, wp_pos in enumerate(full_path):
        ecost = per_step_energy[i] if i < len(per_step_energy) else 0.5
        ok = rover.step_to(wp_pos[0], wp_pos[1], energy_cost=ecost)
        mapper.update(rover.state.position, obstacle_map,
                      heading_rad=rover.state.heading_rad)
        if not ok:
            print("      Battery depleted — rover halted.")
            break

        # Mark waypoints reached
        for wp in all_waypoints:
            if (not wp.visited and
                    wp.position == wp_pos and
                    not wp.visited):
                dist_m = rover.state.odometry_m
                mission.mark_waypoint_reached(wp, dist_m, ecost)

    mission.complete_mission()

    slam_summary = mapper.summary()
    if verbose:
        print(f"      Exploration coverage: "
              f"{slam_summary['exploration_coverage_pct']}%  |  "
              f"Frontiers remaining: {slam_summary['frontier_count']}")

    plot_slam_map(
        mapper.probability_map,
        mapper.known_mask,
        frontier_cells=mapper.frontier_cells,
        rover_path=rover.log.path_xy,
        save_path=os.path.join(results_dir, "slam_map.png"),
    )

    # ------------------------------------------------------------------ #
    # 8. Energy visualization
    # ------------------------------------------------------------------ #
    plot_energy_profile(
        rover.log.battery_history,
        per_step_energy,
        capacity_wh=1500.0,
        save_path=os.path.join(results_dir, "energy_profile.png"),
    )

    # ------------------------------------------------------------------ #
    # 9. Performance evaluation
    # ------------------------------------------------------------------ #
    print("[8/9] Evaluating performance …")
    report = mission.mission_report()

    battery_used = (1500.0 - float(rover.log.battery_history[-1]))
    battery_efficiency = rover.state.odometry_m / (battery_used + 1e-9)

    metrics = {
        "Path Length (cells)"   : float(stats.get("num_cells", 0)),
        "Tortuosity"            : float(stats.get("tortuosity", 1.0)),
        "Energy Used (Wh)"      : round(total_energy_wh, 2),
        "Solar Offset (Wh)"     : round(energy_model.total_solar_wh, 2),
        "Coverage (%)"          : slam_summary["exploration_coverage_pct"],
        "Frontiers Remaining"   : float(slam_summary["frontier_count"]),
        "WPs Completed"         : float(report["waypoints_completed"]),
        "Science Score"         : float(report["total_science_value"]),
        "m per Wh"              : round(battery_efficiency, 3),
    }

    plot_performance_metrics(metrics,
                              save_path=os.path.join(results_dir,
                                                      "performance_metrics.png"))

    # ------------------------------------------------------------------ #
    # Dashboard
    # ------------------------------------------------------------------ #
    print("[9/9] Rendering mission dashboard …")
    plot_mission_dashboard(
        heightmap=terrain.heightmap,
        obstacle_map=obstacle_map,
        path=full_path,
        battery_history=rover.log.battery_history,
        per_step_energy=per_step_energy,
        slam_prob=mapper.probability_map,
        known_mask=mapper.known_mask,
        terrain_labels=(detector.ai_labels if detector.ai_labels is not None
                        else terrain.terrain_labels),
        waypoints=all_waypoints,
        mission_report=report,
        capacity_wh=1500.0,
        save_path=os.path.join(results_dir, "mission_dashboard.png"),
    )

    # ------------------------------------------------------------------ #
    # Text report
    # ------------------------------------------------------------------ #
    mission.print_report()
    report_path = os.path.join(results_dir, "mission_report.txt")
    with open(report_path, "w") as f:
        f.write("LunaRover AI — Mission Report\n")
        f.write("=" * 55 + "\n")
        for k, v in report.items():
            f.write(f"  {k:<28}: {v}\n")
        f.write("\nPerformance Metrics\n")
        f.write("-" * 35 + "\n")
        for k, v in metrics.items():
            f.write(f"  {k:<28}: {v}\n")
        f.write(f"\nTotal wall-clock time : {time.time() - t0:.1f} s\n")

    print(f"\n✓ All outputs saved to '{results_dir}/'")
    print(f"  Wall-clock time: {time.time() - t0:.1f} s\n")

    return {
        "terrain": terrain,
        "obstacle_map": obstacle_map,
        "path": full_path,
        "rover": rover,
        "mapper": mapper,
        "mission_report": report,
        "metrics": metrics,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser(
        description="LunaRover AI — Autonomous Lunar Rover Simulation"
    )
    p.add_argument("--grid_size",   type=int,   default=96,     help="Terrain grid size")
    p.add_argument("--seed",        type=int,   default=42,     help="Random seed")
    p.add_argument("--algorithm",   type=str,   default="astar",
                   choices=["astar", "dijkstra"], help="Path planning algorithm")
    p.add_argument("--n_craters",   type=int,   default=20,     help="Number of craters")
    p.add_argument("--n_waypoints", type=int,   default=5,      help="Science targets")
    p.add_argument("--results_dir", type=str,   default="results", help="Output directory")
    p.add_argument("--quiet",       action="store_true", help="Suppress verbose output")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    run_simulation(
        grid_size   = args.grid_size,
        seed        = args.seed,
        algorithm   = args.algorithm,
        n_craters   = args.n_craters,
        n_waypoints = args.n_waypoints,
        results_dir = args.results_dir,
        verbose     = not args.quiet,
    )
